export { default } from "./MapGoogle";
