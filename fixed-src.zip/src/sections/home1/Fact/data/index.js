export default [
    {
        iconClass:"fe fe-codepen",
        title:"Total Items",
        count:"2569"
    },
    {
        iconClass:"fe fe-shopping-cart",
        title:"Total Sales",
        count:"1765"
    },
    {
        iconClass:"fe fe-users",
        title:"Total Members",
        count:"846"
    },
    {
        iconClass:"icon icon-emotsmile",
        title:"Happy Customers",
        count:"7253"
    }
]