

import sliderImage from "../../../../assets/images/media/pictures/8.jpg";
import sliderUserImage from "../../../../assets/images/users/male/11.jpg";

export default [
    {
    image:sliderImage,
    title:"Excepteur occaecat cupidatat",
    text:"Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat ",
    date:"Nov-19-2020",
    userImage:sliderUserImage,
    userName:"Aracely Bashore",

},
    {
    image:sliderImage,
    title:"Excepteur occaecat cupidatat",
    text:"Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat ",
    date:"Nov-19-2020",
    userImage:sliderUserImage,
    userName:"Aracely Bashore",

},
    {
    image:sliderImage,
    title:"Excepteur occaecat cupidatat",
    text:"Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat ",
    date:"Nov-19-2020",
    userImage:sliderUserImage,
    userName:"Aracely Bashore",

},
    {
    image:sliderImage,
    title:"Excepteur occaecat cupidatat",
    text:"Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip commodo consequat ",
    date:"Nov-19-2020",
    userImage:sliderUserImage,
    userName:"Aracely Bashore",

}
]