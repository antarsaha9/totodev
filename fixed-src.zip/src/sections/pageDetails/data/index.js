
import sliderImage from "../../../assets/images/media/pictures/8.jpg";
import sliderUserImage from "../../../assets/images/users/male/11.jpg";

export default [
    {
    image:sliderImage,
    title:"PHP Template",
    text:"Lorem Ipsum available, quis int lorem ipsum nostrum exercitationem ",
    price:"$25",
    star:"3",
    tag:"PHP",
    userName:"Jessica Turner",
    userImage:sliderUserImage,
    cartCount:"43",
},
    {
    image:sliderImage,
    title:"Wordpress Template",
    text:"Lorem Ipsum available, quis int lorem ipsum nostrum exercitationem ",
    price:"$25",
    star:"3",
    tag:"Wordpress",
    userName:"Anna Howard",
    userImage:sliderUserImage,
    cartCount:"43",
},
    {
    image:sliderImage,
    title:"HTML Template",
    text:"Lorem Ipsum available, quis int lorem ipsum nostrum exercitationem ",
    price:"$25",
    star:"3",
    tag:"HTML",
    userName:"Emily Parsons",
    userImage:sliderUserImage,
    cartCount:"43",
},
    {
    image:sliderImage,
    title:"PSD Template",
    text:"Lorem Ipsum available, quis int lorem ipsum nostrum exercitationem ",
    price:"$25",
    star:"3",
    tag:"PSD",
    userName:"Piers Burgess",
    userImage:sliderUserImage,
    cartCount:"43",
},
    {
    image:sliderImage,
    title:"Angular Template",
    text:"Lorem Ipsum available, quis int lorem ipsum nostrum exercitationem ",
    price:"$25",
    star:"3",
    tag:"Angular",
    userName:"Jessica Turner",
    userImage:sliderUserImage,
    cartCount:"43",
}

]