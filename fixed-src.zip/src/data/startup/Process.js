import Images from "~data/imageImports";
const ProcessData = [
      {
        id:"sp1",
        icon: "1",
        title: "Case Analysis",
        text:
        "Leverage agile frameworks to provide a robust synopsis for high level overviews.",
      },
      {
        id:"sp2",
        icon: "2",
        title: "Strategic Advice",
        text:
        'Leverage agile frameworks to provide a robust synopsis for high level overviews.',
      },
      {
        id:"sp3",
        icon: "3",
        title: "Insight Implementation",
        text:
          "Leverage agile frameworks to provide a robust synopsis for high level overviews.",
      },
  ]
  export default ProcessData;