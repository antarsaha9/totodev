import Images from "~data/imageImports";
const BlogData = [
      {
        id:"bg1",
        image: Images.HomeStartup.blogThumbImg1,
        badge:"Gadgets",
        date:"01 June, 2020",
        title: "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
        user:"By George Lee",
        commentCount:" 1"
      },
      {
        id:"bg2",
        image: Images.HomeStartup.blogThumbImg2,
        badge:"Gadgets",
        date:"01 June, 2020",
        title: "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
        user:"By George Lee",
        commentCount:" 2"
      },
      {
        id:"bg3",
        image: Images.HomeStartup.blogThumbImg3,
        badge:"Gadgets",
        date:"01 June, 2020",
        title: "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
        user:"By George Lee",
        commentCount:" 3"
      },

  ]
  export default BlogData;