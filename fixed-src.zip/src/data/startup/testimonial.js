import {Images} from "~data"
const TestimonialData = {
    testimonial: [
        {
          id:"ts1",
          image:Images.itServices.testiMonialUserImg1,
          icon:"fa fa-quote-left",
          userName: "Design & Vreatives",
          userPosition:"One year with us",
          text:"There are many variations passages of Lorem lpsum form, by injected or randomised words which slightiy believable.",
        },
        {
          id:"ts2",
          image:Images.itServices.testiMonialUserImg2,
          icon:"fa fa-quote-left",
          userName: "John Doe",
          userPosition:"One year with us",
          text:"There are many variations passages of Lorem lpsum form, by injected or randomised words which slightiy believable.",
        },
        {
          id:"ts3",
          image:Images.itServices.testiMonialUserImg3,
          icon:"fa fa-quote-left",
          userName: "Charles Patterson",
          userPosition:"One year with us",
          text:"There are many variations passages of Lorem lpsum form, by injected or randomised words which slightiy believable.",
        },
    ]
}
  export default TestimonialData;