import testiMonialUserImg1 from "~image/it-services/user-circle-1.png";
import testiMonialUserImg2 from "~image/it-services/user-circle-2.png";
import testiMonialUserImg3 from "~image/it-services/user-circle-3.png";
import testiMonialUserImg4 from "~image/it-services/user-circle-4.png";
import testiMonialUserImg5 from "~image/it-services/user-circle-5.png";
import testiMonialUserImg6 from "~image/it-services/user-circle-6.png";
const TestimonialData = {
    testimonial: [
        {
          id:"ts1",
          image:testiMonialUserImg1,
          icon:"fa fa-quote-left",
          userName: "Design & Vreatives",
          userPosition:"One year with us",
          text: "consetetur sadipscing elltr, sed dlam nonumy elrmod tempor invidunt ut labore et dolore magna allquyamerat, sed dlam voluptua.",
        },
        {
          id:"ts2",
          image:testiMonialUserImg2,
          icon:"fa fa-quote-left",
          userName: "John Doe",
          userPosition:"One year with us",
          text: "consetetur sadipscing elltr, sed dlam nonumy elrmod tempor invidunt ut labore et dolore magna allquyamerat, sed dlam voluptua.",
        },
        {
          id:"ts3",
          image:testiMonialUserImg3,
          icon:"fa fa-quote-left",
          userName: "Charles Patterson",
          userPosition:"One year with us",
          text: "consetetur sadipscing elltr, sed dlam nonumy elrmod tempor invidunt ut labore et dolore magna allquyamerat, sed dlam voluptua.",
        },
        {
          id:"ts3",
          image:testiMonialUserImg3,
          icon:"fa fa-quote-left",
          userName: "Charles Patterson",
          userPosition:"One year with us",
          text: "consetetur sadipscing elltr, sed dlam nonumy elrmod tempor invidunt ut labore et dolore magna allquyamerat, sed dlam voluptua.",
        },
        {
          id:"ts3",
          image:testiMonialUserImg3,
          icon:"fa fa-quote-left",
          userName: "Charles Patterson",
          userPosition:"One year with us",
          text: "consetetur sadipscing elltr, sed dlam nonumy elrmod tempor invidunt ut labore et dolore magna allquyamerat, sed dlam voluptua.",
        },
        {
          id:"ts3",
          image:testiMonialUserImg3,
          icon:"fa fa-quote-left",
          userName: "Charles Patterson",
          userPosition:"One year with us",
          text: "consetetur sadipscing elltr, sed dlam nonumy elrmod tempor invidunt ut labore et dolore magna allquyamerat, sed dlam voluptua.",
        },
    ]
}
  export default TestimonialData;