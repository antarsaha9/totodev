import Images from "~data/imageImports";
const BlogData = [
      {
        id:"bg1",
        image: Images.BlogsPage.BlogsImg2,
        badge:"Gadgets",
        date:"01 June, 2020",
        title: "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
        user:"By George Lee",
        Like:"21K",
        commentCount:" 305"
      },
      {
        id:"bg2",
        image: Images.BlogsPage.BlogsImg3,
        badge:"Gadgets",
        date:"01 June, 2020",
        title: "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
        user:"By George Lee",
        Like:"21K",
        commentCount:" 2"
      },
      {
        id:"bg3",
        image: Images.BlogsPage.BlogsImg4,
        badge:"Gadgets",
        date:"01 June, 2020",
        title: "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
        user:"By George Lee",
        Like:"21K",
        commentCount:" 3"
      },
      {
        id:"bg4",
        image: Images.BlogsPage.BlogsImg5,
        badge:"Gadgets",
        date:"01 June, 2020",
        title: "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
        user:"By George Lee",
        Like:"21K",
        commentCount:" 3"
      },
      {
        id:"bg5",
        image: Images.BlogsPage.BlogsImg6,
        badge:"Gadgets",
        date:"01 June, 2020",
        title: "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
        user:"By George Lee",
        Like:"21K",
        commentCount:" 3"
      },
      {
        id:"bg6",
        image: Images.BlogsPage.BlogsImg7,
        badge:"Gadgets",
        date:"01 June, 2020",
        title: "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
        user:"By George Lee",
        Like:"21K",
        commentCount:" 3"
      },

  ]
  export default BlogData;