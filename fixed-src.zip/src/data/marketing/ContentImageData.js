export {default as TabImageMiddle } from "../../assets/image/home-1/l1-hero-img-ipad.png";
export {default as TabImageUser1 } from "../../assets/image/home-1/l1-hero-img-1.png";
export {default as TabImageUser2 } from "../../assets/image/home-1/l1-hero-img-2.png";
export {default as TabImageUser3 } from "../../assets/image/home-1/l1-hero-img-3.png";
export {default as shapeYellow } from "../../assets/image/home-1/l1-hero-shape-1.png";
export {default as shapedots } from "../../assets/image/home-1/hero-dots.png";
export {default as shapeTriangle } from "../../assets/image/home-1/l1-hero-shape-3.png";
export {default as shapeBlue } from "../../assets/image/home-1/l1-hero-shape-2.png";

