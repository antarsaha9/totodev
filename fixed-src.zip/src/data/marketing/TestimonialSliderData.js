// import Images from "~data/imageImports"
import testiMonialUserimg1 from "~image/marketing/user-1.png";
import testiMonialUserimg2 from "~image/marketing/user-2.png";
import testiMonialUserimg3 from "~image/marketing/user-3.png";
const Testimonialdata = [
    {
        image:testiMonialUserimg1,
        text:"Simply the best. Better than all the rest. I’d recommend their service to beginners and advanced users.",
        name:"Mariano Rasgado",
        position:"Founder",
        reviewStar:5,
    },
    {
        image:testiMonialUserimg2,
        text:"Simply the best. Better than all the rest. I’d recommend their service to beginners and advanced users.",
        name:"Mariano Rasgado",
        position:"Founder",
        reviewStar:3,
    },
    {
        image:testiMonialUserimg3,
        text:"Simply the best. Better than all the rest. I’d recommend their service to beginners and advanced users.",
        name:"Mariano Rasgado",
        position:"Founder",
        reviewStar:2,
    }
]


export default Testimonialdata;

