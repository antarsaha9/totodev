// import HeaderButton from "~components/core/Header/InnerPageHeader"
// import {Link} from "~components";
// // import siteLogo from "~image/site-logo.png"

// const headerInnerpageDefaultConfig = {
//     headerClasses:"light-header site-header--menu-end site-header--button-sep position-relative",
//     containerFluid:false,
//     darkLogo:true,
//     buttonBlock:(<HeaderButton as={Link} btnText="Purchase"/>)
// }

// export default  headerInnerpageDefaultConfig