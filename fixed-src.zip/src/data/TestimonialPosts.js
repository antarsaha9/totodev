import l3testiMonialUserImg1 from "~image/it-services/user-circle-1.png";
import l3testiMonialUserImg2 from "~image/it-services/user-circle-2.png";
import l3testiMonialUserImg3 from "~image/it-services/user-circle-3.png";
import l3testiMonialUserImg4 from "~image/it-services/user-circle-4.png";
import l3testiMonialUserImg5 from "~image/it-services/user-circle-5.png";
import l3testiMonialUserImg6 from "~image/it-services/user-circle-6.png";
const TestimonialPosts = [
    {
    text:"There are many variations passages of Lorem lpsum available, but the majority have suffered alteration in some form, by injected or randomised.",
    userImage:l3testiMonialUserImg1,
    userName:"Gary Simon",
    userPosition:"Sholl’s Colonial Cafeteria"
},
{
    text:"There are many variations passages of Lorem lpsum available, but the majority have suffered alteration in some form, by injected or randomised.",
    userImage:l3testiMonialUserImg2,
    userName:"Karla Lynn",
    userPosition:"Sholl’s Colonial Cafeteria"
},
{
    text:"There are many variations passages of Lorem lpsum available, but the majority have suffered alteration in some form, by injected or randomised.",
    userImage:l3testiMonialUserImg3,
    userName:"Stella Jennifer",
    userPosition:"Sholl’s Colonial Cafeteria"
},
{
    text:"There are many variations passages of Lorem lpsum available, but the majority have suffered alteration in some form, by injected or randomised.",
    userImage:l3testiMonialUserImg4,
    userName:"Gary Simon",
    userPosition:"Sholl’s Colonial Cafeteria"
},
{
    text:"There are many variations passages of Lorem lpsum available, but the majority have suffered alteration in some form, by injected or randomised.",
    userImage:l3testiMonialUserImg5,
    userName:"Karla Lynn",
    userPosition:"Sholl’s Colonial Cafeteria"
},
{
    text:"There are many variations passages of Lorem lpsum available, but the majority have suffered alteration in some form, by injected or randomised.",
    userImage:l3testiMonialUserImg6,
    userName:"Stella Jennifer",
    userPosition:"Sholl’s Colonial Cafeteria"
}
]

export default TestimonialPosts;