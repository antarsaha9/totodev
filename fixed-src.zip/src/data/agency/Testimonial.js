import Images from "~data/imageImports";
const TestimonialData =[
        {
          id:"at1",
          image: Images.Agency.testiMonialUserimg1,
          userName: "Jonathon Tyler",
          userPosition: "CEO at Creativex",
          text:
            "@Fastland is great for creating landing pages within minutes! It actually takes less time.",
        },
        {
          id:"at2",
          image: Images.Agency.testiMonialUserimg2,
          userName: "Angela Park",
          userPosition: "CEO at Orbital",
          text:
            "@Fastland is great for creating landing pages within minutes! It actually takes less time.",
        },
        {
          id:"at3",
          image: Images.Agency.testiMonialUserimg3,
          userName: "Gavin Brendon",
          userPosition: "Freelance Designer",
          text:
            "@Fastland is great for creating landing pages within minutes! It actually takes less time.",
        },
      ]
  export default TestimonialData;