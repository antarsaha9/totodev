const contentData = {
    services: [
        {
          id:"ac1",
          title: "Our Customer",
          text:
            "Business advisory service advises current and future businesses prospects of a client, with the aim of",
        },
        {
          id:"ac2",
          title: "Our Product",
          text:
            "Business advisory service advises current and future businesses prospects of a client, with the aim of",
        },
        {
          id:"ac3",
          title: "Our Services",
          text:
            "Business advisory service advises current and future businesses prospects of a client, with the aim of",
        },
      ]
  }
  export default contentData;