const ServiceData = [
        {
          id:"is1",
          icon:"fas fa-envelope",
          title: "Product Management",
          text: "50 availabe vacancy",
          iconBackground:"#1de2cf"
        },
        {
          id:"is2",
          icon:"fas fa-layer-group",
          title: "Web & Mobile Development",
          text:"50 availabe vacancy",
          iconBackground:"#494ca2"
        },
        {
          id:"is3",
          icon:"fas fa-headphones",
          title: "Customer Support",
          text: "50 availabe vacancy",
          iconBackground:"#0f89ff"
        },
        {
          id:"is4",
          icon:"fas fa-bell",
          title: "Human Resources",
          text: "50 availabe vacancy",
          iconBackground:"#ff5722"
        },
        {
          id:"is5",
          icon:"fas fa-file-invoice",
          title: "Design & vreatives",
          text:"50 availabe vacancy",
          iconBackground:"#0f89ff"
        },
        {
          id:"is6",
          icon:"fas fa-chart-pie",
          title: "Marketing & Commuication",
          text:"50 availabe vacancy",
          iconBackground:"#0cd68a"
        },
        {
          id:"is7",
          icon:"fas fa-money-bill-alt",
          title:"Business Development",
          text:"50 availabe vacancy",
          iconBackground:"#fcdc00"
        }
    
    ]
  export default ServiceData;